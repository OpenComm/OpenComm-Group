package ssDemo.BlueThroatedBarbet;

import android.media.*;

/** This class implements AudioPlayer interface;
 * manipulates sound spatialization using a raw resource */
public class AudioRaw implements AudioPlayer {

	private float degree; // direction from which the sound is coming; 0 is directly in front of center
	private float distance; // distance from which the sound comes
	private float delay; // interaural time difference
	private AudioTrack left; // sound controlling left hearing
	private AudioTrack right; // sound controlling right hearing
	private static float xOrigin;
	private static float yOrigin;
	
	
	public void pause() {
		// TODO Auto-generated method stub

	}

	public void play() {
		// TODO Auto-generated method stub

	}

	public void stop() {
		// TODO Auto-generated method stub

	}

	public void write(short[] data) {
		// TODO Auto-generated method stub

	}

	public void write(byte[] data) {
		// TODO Auto-generated method stub

	}
	/** Constructor: creates a new source of sound based on degree and distance */
	public AudioRaw(float deg, float dist) {
		this.degree = deg;
		this.distance = dist;
		this.left = new AudioTrack(AudioManager.STREAM_MUSIC, 8000, AudioFormat.CHANNEL_CONFIGURATION_MONO, AudioFormat.ENCODING_PCM_16BIT, 1024*2*2, AudioTrack.MODE_STREAM);
		this.right = new AudioTrack(AudioManager.STREAM_MUSIC, 8000, AudioFormat.CHANNEL_CONFIGURATION_MONO, AudioFormat.ENCODING_PCM_16BIT, 1024*2*2, AudioTrack.MODE_STREAM);
	}
	
	/** Constructor: calculates degree and distance using the coordinates of point */
	public AudioRaw(int xCoord, int yCoord) {
		this.distance = (float) Math.sqrt(Math.pow(xCoord - xOrigin,2) + Math.pow(yCoord - yOrigin,2));
		this.degree = (float) Math.asin((yOrigin - yCoord)/(xCoord - xOrigin));
		this.delay = (float) ((0.11 / 343.42) * (this.degree + Math.sin(this.degree)));
		this.left = new AudioTrack(AudioManager.STREAM_MUSIC, 8000, AudioFormat.CHANNEL_CONFIGURATION_MONO, AudioFormat.ENCODING_PCM_16BIT, 1024*2*2, AudioTrack.MODE_STREAM);
		this.right = new AudioTrack(AudioManager.STREAM_MUSIC, 8000, AudioFormat.CHANNEL_CONFIGURATION_MONO, AudioFormat.ENCODING_PCM_16BIT, 1024*2*2, AudioTrack.MODE_STREAM);
	}

}
