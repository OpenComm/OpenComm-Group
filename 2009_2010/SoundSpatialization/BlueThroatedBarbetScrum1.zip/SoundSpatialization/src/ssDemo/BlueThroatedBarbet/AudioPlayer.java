package ssDemo.BlueThroatedBarbet;
/** This interface manipulates sound of 
 * various sources for demo purpose */
public interface AudioPlayer {
	void play(); // plays both audio objects with corresponding interval in between
	void pause(); // pauses both audio objects with corresponding interval in between
	void stop(); // stops both audio objects
	void write(short[] data); // writes pcm audio data
	void write(byte[] data);
}
