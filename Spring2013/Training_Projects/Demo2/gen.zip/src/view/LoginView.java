package view;

import controller.LoginController;
import android.app.Activity;
import android.os.Bundle;


public class LoginView extends Activity {
	
	private LoginController loginController;
	
	public void onCreate(Bundle savedInstanceState){
		
	}
}
