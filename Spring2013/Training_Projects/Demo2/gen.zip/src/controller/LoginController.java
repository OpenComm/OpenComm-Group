package controller;

import view.LoginView;


public class LoginController {
	
	private LoginView loginView;
	
	public LoginController(LoginView view) {
		this.loginView = view;
	}
	
	public void signIn(String username, String password){
		//Implementation here
	}
}
